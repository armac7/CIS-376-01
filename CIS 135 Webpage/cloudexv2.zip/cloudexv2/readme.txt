I started working on this on 8/22/21 as the first HTML project. I had big ambitions, and got in over my head. I wanted it to look clean, modern, and nice while being
unable to keep up with that in terms of coding skills. Through trial and error, I created the first version (my first submission.) There was another version before this
one, which resembled the first one a lot more; however, I decided to scrap it entirely. All three version were coded from scratch without the use of my prior code, as this
was to make sure I could optimize it and clean it up without having to go back and look through messy code. I've dabbled in HTML back in 7th grade (aka many many years ago) 
but never anything advanced (I never made my own website). However, through dedication to become a better coder, I've used this as an experience to sink my feet in, stand
my ground, and learn more about a language I want to use more as a freelance coder in the future.